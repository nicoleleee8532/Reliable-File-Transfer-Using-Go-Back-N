# create_test_file.py
with open("input.dat", "wb") as f:
    f.write(b"A" * 3 * 1024 * 1024)  # 3MB of 'A'
print("Created 3MB test file: input.dat")