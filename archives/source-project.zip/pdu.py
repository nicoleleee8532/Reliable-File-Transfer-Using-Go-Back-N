import binascii
FLAG_DATA = 0
FLAG_ACK = 1
FLAG_FIN = 2

def crc(data: bytes):
    return binascii.crc_hqx(data, 0xffff)

class PDU:
    def __init__(self, seq, ack, flags, data):
        self.seq = seq
        self.ack = ack
        self.flags = flags
        self.data = data

    # ---------------- CRC-CCITT ----------------
    @staticmethod
    def crc16(data: bytes):
        crc = 0xFFFF
        for b in data:
            crc ^= b << 8
            for _ in range(8):
                if crc & 0x8000:
                    crc = (crc << 1) ^ 0x1021
                else:
                    crc <<= 1
                crc &= 0xFFFF
        return crc

    # ---------------- ENCODE ----------------
    def encode(self):
        header = f"{self.seq},{self.ack},{self.flags}".encode()
        raw = header + b"|" + self.data
        checksum = crc(raw)

        return raw + b"|" + str(checksum).encode()

    # ---------------- DECODE ----------------
    @staticmethod
    def decode(bytestr):
        parts = bytestr.split(b"|")
        if len(parts) < 3:
            return None
        
        raw = parts[0] + b"|" + parts[1]
        recv_checksum = int(parts[2])

        if crc(raw) != recv_checksum:
            return None  # corrupted

        # Parse header
        header_parts = parts[0].split(b",")
        seq = int(header_parts[0])
        ack = int(header_parts[1])
        flags = int(header_parts[2])
        data = parts[1]
        
        return PDU(seq, ack, flags, data)