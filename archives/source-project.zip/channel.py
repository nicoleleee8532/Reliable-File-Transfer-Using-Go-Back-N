import random

def simulate(data, loss_rate, error_rate):

    if random.randint(1, loss_rate) == 1:
        return None

    if random.randint(1, error_rate) == 1:
        b = bytearray(data)
        b[0] ^= 1
        return bytes(b)

    return data