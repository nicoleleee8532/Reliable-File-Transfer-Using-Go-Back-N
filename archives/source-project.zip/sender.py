from pdu import PDU
from utils import create_socket
import configparser
import time
import socket
from channel_wrapper import send_via_channel

# ================= CONFIG =================
config = configparser.ConfigParser()
config.read("config.ini")

PORT = int(config["COMMUNICATION"]["UDPPort"])
DATA_SIZE = int(config["COMMUNICATION"]["DataSize"])
WINDOW_SIZE = int(config["COMMUNICATION"]["SWSize"])
TIMEOUT = float(config["COMMUNICATION"]["Timeout"]) / 1000

receiver = ("127.0.0.1", PORT)

# ================= SOCKET =================
sock = create_socket()
sock.settimeout(TIMEOUT)

# ================= FILE =================
with open("input.dat", "rb") as f:
    file_data = f.read()

chunks = [file_data[i:i+DATA_SIZE] for i in range(0, len(file_data), DATA_SIZE)]
total_packets = len(chunks)

print("Total packets:", total_packets)

# ================= GBN STATE =================
base = 0
nextseq = 0
buffer = {}

log = open("sender_log.txt", "w")
log_id = 1

retrans_count = 0
timeout_count = 0

# ================= TIMER =================
start_time = time.time()

# ================= MAIN LOOP =================
while base < total_packets:

    # -------- send window --------
    while nextseq < base + WINDOW_SIZE and nextseq < total_packets:
        pkt = PDU(nextseq, 0, 0, chunks[nextseq])
        encoded = pkt.encode()
        
        # Use channel simulation
        send_via_channel(sock, encoded, receiver)
        
        buffer[nextseq] = pkt
        print("SEND", nextseq)
        
        log.write(f"{log_id}, pdu_to_send={nextseq}, status=New, ackedNo={base-1}\n")
        log_id += 1
        nextseq += 1


    # -------- receive ACK --------
    try:
        data, _ = sock.recvfrom(4096)
        ack_pkt = PDU.decode(data)

        if ack_pkt:
            print("ACK RECEIVED:", ack_pkt.ack)

            # IMPORTANT FIX: cumulative ACK
            if ack_pkt.ack >= base:
                base = ack_pkt.ack + 1

    # -------- timeout --------
    except (socket.timeout, TimeoutError):
        print("TIMEOUT")
        timeout_count += 1
        
        for seq in range(base, nextseq):
            pkt = buffer[seq]
            encoded = pkt.encode()
            send_via_channel(sock, encoded, receiver)  # Use channel here too
            
            retrans_count += 1
            print("RETRANSMIT", seq)
            
            log.write(f"{log_id}, pdu_to_send={seq}, status=TO, ackedNo={base-1}\n")
            log_id += 1

# ================= FIN =================
fin = PDU(total_packets, 0, 1, b"FIN")
send_via_channel(sock, fin.encode(), receiver)

end_time = time.time()

print("\nTRANSFER COMPLETE")
print("Time:", end_time - start_time)
print("Timeouts:", timeout_count)
print("Retransmissions:", retrans_count)

log.close()
sock.close()

log.write(f"TOTAL_TIME={end_time - start_time}\n")
INIT_SEQ = int(config["COMMUNICATION"]["InitSeqNo"])
base = INIT_SEQ
nextseq = INIT_SEQ