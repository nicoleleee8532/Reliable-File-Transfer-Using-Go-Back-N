# checksum.py

CRC_POLY = 0x1021

def crc_ccitt(data: bytes) -> int:
    crc = 0xFFFF

    for byte in data:
        crc ^= (byte << 8)

        for _ in range(8):
            if crc & 0x8000:
                crc = (crc << 1) ^ CRC_POLY
            else:
                crc = crc << 1

            crc &= 0xFFFF

    return crc


def add_checksum(data: bytes) -> bytes:
    crc = crc_ccitt(data)
    return data + crc.to_bytes(2, "big")


def verify_checksum(data: bytes) -> bool:
    if len(data) < 2:
        return False

    body = data[:-2]
    recv_crc = int.from_bytes(data[-2:], "big")

    return crc_ccitt(body) == recv_crc