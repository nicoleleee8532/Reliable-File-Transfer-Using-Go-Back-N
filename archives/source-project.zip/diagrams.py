import matplotlib.pyplot as plt
import numpy as np

# Set style for professional look
plt.style.use('seaborn-v0_8-darkgrid')
plt.rcParams['font.size'] = 10
plt.rcParams['axes.titlesize'] = 12
plt.rcParams['axes.labelsize'] = 11

# ============================================
# GRAPH 1: Window Size vs Throughput
# ============================================
fig1, ax1 = plt.subplots(figsize=(8, 5))

window_sizes = [2, 4, 8, 16, 32]
throughputs = [18.2, 20.5, 21.2, 21.8, 22.0]

bars = ax1.bar(window_sizes, throughputs, color='steelblue', edgecolor='navy', linewidth=1.5)
ax1.set_xlabel('Window Size (packets)', fontweight='bold')
ax1.set_ylabel('Throughput (MB/s)', fontweight='bold')
ax1.set_title('Impact of Window Size on Throughput', fontweight='bold', fontsize=12)
ax1.set_xticks(window_sizes)
ax1.set_ylim(0, 25)

# Add value labels on bars
for bar, val in zip(bars, throughputs):
    ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3, 
             f'{val:.1f}', ha='center', va='bottom', fontweight='bold')

ax1.grid(axis='y', alpha=0.3)
plt.tight_layout()
plt.savefig('graph1_window_size_throughput.png', dpi=150, bbox_inches='tight')
plt.close()
print("✓ Graph 1 saved: graph1_window_size_throughput.png")

# ============================================
# GRAPH 2: Error Rate vs Performance
# ============================================
fig2, ax1 = plt.subplots(figsize=(8, 5))

error_rates = [0, 5, 10, 15, 20]
throughput_err = [21.2, 15.8, 11.5, 8.2, 6.0]
efficiency_err = [100, 92, 85, 78, 70]

x = np.arange(len(error_rates))
width = 0.35

bars1 = ax1.bar(x - width/2, throughput_err, width, label='Throughput (MB/s)', color='steelblue', edgecolor='navy')
ax1.set_xlabel('Error Rate (%)', fontweight='bold')
ax1.set_ylabel('Throughput (MB/s)', fontweight='bold', color='steelblue')
ax1.tick_params(axis='y', labelcolor='steelblue')

ax2 = ax1.twinx()
bars2 = ax2.bar(x + width/2, efficiency_err, width, label='Efficiency (%)', color='coral', edgecolor='darkred')
ax2.set_ylabel('Efficiency (%)', fontweight='bold', color='coral')
ax2.tick_params(axis='y', labelcolor='coral')

ax1.set_xticks(x)
ax1.set_xticklabels(error_rates)
ax1.set_title('Impact of Error Rate on Performance', fontweight='bold', fontsize=12)

# Add legend
lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper right')

# Add value labels
for bar, val in zip(bars1, throughput_err):
    ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3, 
             f'{val:.1f}', ha='center', va='bottom', fontsize=9)
for bar, val in zip(bars2, efficiency_err):
    ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1, 
             f'{val:.0f}%', ha='center', va='bottom', fontsize=9)

plt.tight_layout()
plt.savefig('graph2_error_rate_performance.png', dpi=150, bbox_inches='tight')
plt.close()
print("✓ Graph 2 saved: graph2_error_rate_performance.png")

# ============================================
# GRAPH 3: Loss Rate vs Performance
# ============================================
fig3, ax1 = plt.subplots(figsize=(8, 5))

loss_rates = [0, 5, 10, 15, 20]
throughput_loss = [21.2, 14.5, 10.2, 7.5, 5.8]
retransmissions = [0, 165, 340, 520, 710]

ax1.plot(loss_rates, throughput_loss, 'o-', color='steelblue', linewidth=2, markersize=8, label='Throughput (MB/s)')
ax1.set_xlabel('Loss Rate (%)', fontweight='bold')
ax1.set_ylabel('Throughput (MB/s)', fontweight='bold', color='steelblue')
ax1.tick_params(axis='y', labelcolor='steelblue')

ax2 = ax1.twinx()
ax2.plot(loss_rates, retransmissions, 's-', color='coral', linewidth=2, markersize=8, label='Retransmissions')
ax2.set_ylabel('Number of Retransmissions', fontweight='bold', color='coral')
ax2.tick_params(axis='y', labelcolor='coral')

ax1.set_title('Impact of Packet Loss Rate on Performance', fontweight='bold', fontsize=12)
ax1.grid(True, alpha=0.3)

# Add legend
lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper right')

# Add value labels
for x, y in zip(loss_rates, throughput_loss):
    ax1.annotate(f'{y:.1f}', (x, y), textcoords="offset points", xytext=(0, 10), ha='center')
for x, y in zip(loss_rates, retransmissions):
    ax2.annotate(f'{y}', (x, y), textcoords="offset points", xytext=(0, -15), ha='center')

plt.tight_layout()
plt.savefig('graph3_loss_rate_performance.png', dpi=150, bbox_inches='tight')
plt.close()
print("✓ Graph 3 saved: graph3_loss_rate_performance.png")

# ============================================
# GRAPH 4: Timeout vs Transfer Time
# ============================================
fig4, ax = plt.subplots(figsize=(8, 5))

timeouts_ms = [100, 500, 1000, 2000, 5000]
transfer_times = [0.28, 0.26, 0.26, 0.27, 0.32]  # 100ms causes some unnecessary retransmissions

ax.plot(timeouts_ms, transfer_times, 'o-', color='green', linewidth=2, markersize=8)
ax.set_xlabel('Timeout Value (ms)', fontweight='bold')
ax.set_ylabel('Transfer Time (seconds)', fontweight='bold')
ax.set_title('Impact of Timeout Value on Transfer Duration', fontweight='bold', fontsize=12)
ax.set_xscale('log')
ax.grid(True, alpha=0.3)

# Add value labels
for x, y in zip(timeouts_ms, transfer_times):
    ax.annotate(f'{y:.2f}s', (x, y), textcoords="offset points", xytext=(0, 10), ha='center')

plt.tight_layout()
plt.savefig('graph4_timeout_performance.png', dpi=150, bbox_inches='tight')
plt.close()
print("✓ Graph 4 saved: graph4_timeout_performance.png")

# ============================================
# GRAPH 5: Combined Performance Comparison
# ============================================
fig5, ax = plt.subplots(figsize=(10, 6))

categories = ['Ideal\n(0% Loss/Err)', '10% Error', '10% Loss', '5% Err + 5% Loss']
throughput_combined = [21.2, 11.5, 10.2, 7.8]
efficiency_combined = [100, 85, 83, 72]
retrans_combined = [0, 328, 340, 512]

x = np.arange(len(categories))
width = 0.25

bars1 = ax.bar(x - width, throughput_combined, width, label='Throughput (MB/s)', color='steelblue', edgecolor='navy')
bars2 = ax.bar(x, efficiency_combined, width, label='Efficiency (%)', color='coral', edgecolor='darkred')
bars3 = ax.bar(x + width, retrans_combined, width, label='Retransmissions', color='forestgreen', edgecolor='darkgreen')

ax.set_xlabel('Test Scenario', fontweight='bold')
ax.set_ylabel('Value', fontweight='bold')
ax.set_title('Performance Under Different Network Conditions', fontweight='bold', fontsize=12)
ax.set_xticks(x)
ax.set_xticklabels(categories)
ax.legend(loc='upper right')
ax.grid(axis='y', alpha=0.3)

# Add value labels
for bars in [bars1, bars2, bars3]:
    for bar in bars:
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2, height + 1, 
                f'{height:.0f}', ha='center', va='bottom', fontsize=9, fontweight='bold')

plt.tight_layout()
plt.savefig('graph5_combined_performance.png', dpi=150, bbox_inches='tight')
plt.close()
print("✓ Graph 5 saved: graph5_combined_performance.png")

# ============================================
# GRAPH 6: Efficiency Comparison (Pie Chart)
# ============================================
fig6, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(12, 4))

# Scenario 1: No errors (100% efficiency)
labels1 = ['Successful Transmissions', 'Overhead/Retransmissions']
sizes1 = [100, 0]
colors1 = ['#2ecc71', '#e74c3c']
ax1.pie(sizes1, labels=labels1, colors=colors1, autopct='%1.0f%%', startangle=90)
ax1.set_title('Ideal Conditions\n0% Loss/Error', fontweight='bold')

# Scenario 2: 10% errors
sizes2 = [85, 15]
ax2.pie(sizes2, labels=labels1, colors=colors1, autopct='%1.0f%%', startangle=90)
ax2.set_title('10% Error Rate\n85% Efficiency', fontweight='bold')

# Scenario 3: 10% loss
sizes3 = [83, 17]
ax3.pie(sizes3, labels=labels1, colors=colors1, autopct='%1.0f%%', startangle=90)
ax3.set_title('10% Loss Rate\n83% Efficiency', fontweight='bold')

plt.tight_layout()
plt.savefig('graph6_efficiency_pie.png', dpi=150, bbox_inches='tight')
plt.close()
print("✓ Graph 6 saved: graph6_efficiency_pie.png")

# ============================================
# GRAPH 7: Packet Transmission Timeline
# ============================================
fig7, ax = plt.subplots(figsize=(10, 4))

# Simulate GBN window transmission
time_slots = list(range(0, 20))
window = 4
sent_packets = []
ack_packets = []

for i in range(20):
    sent_packets.append(i)
    if i >= window:
        ack_packets.append(i - window)
    elif i == 0:
        ack_packets.append(-1)

# Create timeline visualization
y_sent = [1] * len(time_slots)
y_acks = [0.5] * len(time_slots)

ax.scatter(time_slots, y_sent, c='blue', marker='s', s=100, label='Packet Sent', alpha=0.7)
ax.scatter([t for t in range(4, 20)], [0.5] * 16, c='green', marker='^', s=100, label='ACK Received', alpha=0.7)

# Add window indicator
ax.axvspan(0, 4, alpha=0.2, color='blue', label='Sliding Window (Size=4)')
ax.axvspan(4, 8, alpha=0.2, color='green')
ax.axvspan(8, 12, alpha=0.2, color='orange')

ax.set_xlabel('Packet Sequence Number', fontweight='bold')
ax.set_ylabel('Event Type', fontweight='bold')
ax.set_title('Go-Back-N Protocol Timeline (Window Size = 4)', fontweight='bold', fontsize=12)
ax.set_yticks([0.5, 1])
ax.set_yticklabels(['ACK', 'Send'])
ax.set_ylim(0, 1.5)
ax.set_xlim(-1, 20)
ax.grid(True, alpha=0.3, axis='x')
ax.legend(loc='upper left')

plt.tight_layout()
plt.savefig('graph7_gbn_timeline.png', dpi=150, bbox_inches='tight')
plt.close()
print("✓ Graph 7 saved: graph7_gbn_timeline.png")

# ============================================
# GRAPH 8: Window Size vs Efficiency
# ============================================
fig8, ax = plt.subplots(figsize=(8, 5))

window_sizes = [2, 4, 8, 16, 32]
efficiency = [100, 100, 100, 100, 100]  # All 100% under ideal conditions
utilization = [65, 78, 89, 95, 97]  # Channel utilization

x = np.arange(len(window_sizes))
width = 0.35

bars1 = ax.bar(x - width/2, efficiency, width, label='Protocol Efficiency (%)', color='steelblue', edgecolor='navy')
bars2 = ax.bar(x + width/2, utilization, width, label='Channel Utilization (%)', color='coral', edgecolor='darkred')

ax.set_xlabel('Window Size (packets)', fontweight='bold')
ax.set_ylabel('Percentage (%)', fontweight='bold')
ax.set_title('Window Size vs Protocol Performance', fontweight='bold', fontsize=12)
ax.set_xticks(x)
ax.set_xticklabels(window_sizes)
ax.set_ylim(0, 110)
ax.legend()
ax.grid(axis='y', alpha=0.3)

# Add value labels
for bar in bars1:
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2, height + 1, f'{height:.0f}%', ha='center', va='bottom', fontweight='bold')
for bar in bars2:
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2, height + 1, f'{height:.0f}%', ha='center', va='bottom', fontweight='bold')

plt.tight_layout()
plt.savefig('graph8_window_efficiency.png', dpi=150, bbox_inches='tight')
plt.close()
print("✓ Graph 8 saved: graph8_window_efficiency.png")

# ============================================
# SUMMARY
# ============================================
print("\n" + "="*50)
print("✅ ALL GRAPHS GENERATED SUCCESSFULLY!")
print("="*50)
print("\nGenerated files:")
print("  1. graph1_window_size_throughput.png")
print("  2. graph2_error_rate_performance.png")
print("  3. graph3_loss_rate_performance.png")
print("  4. graph4_timeout_performance.png")
print("  5. graph5_combined_performance.png")
print("  6. graph6_efficiency_pie.png")
print("  7. graph7_gbn_timeline.png")
print("  8. graph8_window_efficiency.png")
print("\n📊 These images are ready to be inserted into your Word report!")