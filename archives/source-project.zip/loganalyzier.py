import matplotlib.pyplot as plt
import numpy as np

def analyze_log(file):
    stats = {
        'total_transmissions': 0,
        'new_packets': 0,
        'timeouts': 0,
        'retransmissions': 0,
        'corrupted': 0,
        'out_of_order': 0,
        'total_time': 1  # Default to 1 to avoid division by zero
    }
    
    with open(file, "r") as f:
        for line in f:
            stats['total_transmissions'] += 1
            if "status=New" in line:
                stats['new_packets'] += 1
            if "status=TO" in line:
                stats['timeouts'] += 1
                stats['retransmissions'] += 1
            if "status=DataErr" in line:
                stats['corrupted'] += 1
            if "status=NoErr" in line:
                stats['out_of_order'] += 1
            if "TOTAL_TIME=" in line:
                stats['total_time'] = float(line.split("=")[1])
    
    return stats

def analyze_multiple_configs():
    """Test different configurations and compare"""
    configs = [
        {"SWSize": 4, "ErrorRate": 0, "LostRate": 0, "Timeout": 1000},
        {"SWSize": 8, "ErrorRate": 0, "LostRate": 0, "Timeout": 1000},
        {"SWSize": 4, "ErrorRate": 10, "LostRate": 0, "Timeout": 1000},
        {"SWSize": 4, "ErrorRate": 0, "LostRate": 10, "Timeout": 1000},
        {"SWSize": 4, "ErrorRate": 0, "LostRate": 0, "Timeout": 500},
    ]
    
    results = []
    for config in configs:
        # Run test with this config
        # (You'll need to run sender/receiver programmatically)
        stats = analyze_log("sender_log.txt")
        results.append(stats)
    
    # Plot comparison
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    
    # Throughput comparison
    throughputs = [r['new_packets'] / r['total_time'] for r in results]
    axes[0,0].bar(range(len(configs)), throughputs)
    axes[0,0].set_title('Throughput by Configuration')
    
    # Retransmission efficiency
    retrans_rates = [r['retransmissions'] / r['new_packets'] for r in results]
    axes[0,1].bar(range(len(configs)), retrans_rates)
    axes[0,1].set_title('Retransmission Rate')
    
    # Timeout impact
    timeout_rates = [r['timeouts'] / r['total_transmissions'] for r in results]
    axes[1,0].bar(range(len(configs)), timeout_rates)
    axes[1,0].set_title('Timeout Rate')
    
    # Efficiency = new_packets / total_transmissions
    efficiency = [r['new_packets'] / r['total_transmissions'] for r in results]
    axes[1,1].bar(range(len(configs)), efficiency)
    axes[1,1].set_title('Communication Efficiency')
    
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    stats = analyze_log("sender_log.txt")
    print("=== STATISTICS ===")
    for key, value in stats.items():
        print(f"{key}: {value}")
    
    analyze_multiple_configs()