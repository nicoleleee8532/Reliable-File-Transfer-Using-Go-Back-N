import re

new = 0
to = 0
total = 0
duration = 1

with open("sender_log.txt", "r") as f:
    for line in f:
        total += 1

        if "status=New" in line:
            new += 1

        if "status=TO" in line:
            to += 1

        if "TOTAL_TIME=" in line:
            duration = float(line.strip().split("=")[1])

throughput = total / duration
efficiency = new / total if total > 0 else 0

print("===== ANALYSIS =====")
print("Total transmissions:", total)
print("New packets:", new)
print("Timeout retransmissions:", to)
print("Time (s):", duration)
print("Throughput (pkts/s):", throughput)
print("Efficiency:", efficiency)