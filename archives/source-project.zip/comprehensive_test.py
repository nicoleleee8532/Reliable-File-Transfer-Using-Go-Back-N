cat > simple_test.py << 'EOF'
import subprocess
import time
import os
import sys
import configparser

def run_quick_test():
    print("\n" + "="*60)
    print("QUICK VERIFICATION TEST")
    print("="*60)
    
    # Create 5MB test file
    size_bytes = 5 * 1024 * 1024
    with open("input.dat", "wb") as f:
        f.write(b'A' * size_bytes)
    print(f"Created input.dat: {size_bytes:,} bytes (5.00 MB)")
    
    # Run with default settings
    config = configparser.ConfigParser()
    config.read("config.ini")
    config["COMMUNICATION"]["SWSize"] = "8"
    config["COMMUNICATION"]["ErrorRate"] = "0"
    config["COMMUNICATION"]["LostRate"] = "0"
    
    with open("config.ini", "w") as f:
        config.write(f)
    
    # Clean old files
    for f in ["sender_log.txt", "receiver_log.txt", "received.dat"]:
        if os.path.exists(f):
            os.remove(f)
    
    # Start receiver
    receiver = subprocess.Popen([sys.executable, "receiver.py"], 
                                stdout=subprocess.PIPE, 
                                stderr=subprocess.PIPE)
    time.sleep(1)
    
    # Run sender
    start = time.time()
    sender = subprocess.run([sys.executable, "sender.py"], 
                           capture_output=True, 
                           text=True)
    duration = time.time() - start
    
    time.sleep(0.5)
    receiver.terminate()
    
    # Check results
    input_size = os.path.getsize("input.dat")
    received_size = os.path.getsize("received.dat") if os.path.exists("received.dat") else 0
    
    print(f"\n{'─'*60}")
    print("TEST RESULTS")
    print(f"{'─'*60}")
    print(f"Duration:        {duration:.3f} seconds")
    print(f"Throughput:      {(input_size/(1024*1024))/duration:.2f} MB/s")
    print(f"Input size:      {input_size:,} bytes")
    print(f"Received size:   {received_size:,} bytes")
    
    if input_size == received_size:
        print("\n✓ FILE INTEGRITY: PASS - Files match perfectly!")
        print("\n✅ TEST PASSED! Your GBN implementation is working correctly.")
    else:
        print("\n✗ FILE INTEGRITY: FAIL - Files don't match!")
        print("\n❌ TEST FAILED! Please check your implementation.")
    
    # Show log summary
    if os.path.exists("sender_log.txt"):
        with open("sender_log.txt", "r") as f:
            new_count = sum(1 for line in f if "status=New" in line)
        print(f"\nSender log: {new_count} new packets sent")
    
    if os.path.exists("receiver_log.txt"):
        with open("receiver_log.txt", "r") as f:
            ok_count = sum(1 for line in f if "status=OK" in line)
        print(f"Receiver log: {ok_count} packets received correctly")

if __name__ == "__main__":
    run_quick_test()
EOF

# Run the simple test
python3 simple_test.py