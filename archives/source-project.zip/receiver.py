from pdu import PDU
from utils import create_socket
import configparser
from channel_wrapper import send_via_channel

# ================= CONFIG =================
config = configparser.ConfigParser()
config.read("config.ini")

PORT = int(config["COMMUNICATION"]["UDPPort"])
DATA_SIZE = int(config["COMMUNICATION"]["DataSize"])

# ================= SOCKET =================
sock = create_socket()
sock.bind(("0.0.0.0", PORT))
TIMEOUT = float(config["COMMUNICATION"]["Timeout"]) / 1000
sock.settimeout(TIMEOUT)

print("Receiver started on port", PORT)

# ================= STATE =================
expected_seq = 0

# ================= FILE =================
output_file = open("received.dat", "wb")
log = open("receiver_log.txt", "w")
log_id = 1

# ================= MAIN LOOP =================
while True:

    data, addr = sock.recvfrom(65535)
    pkt = PDU.decode(data)

    # -------------------------
    # CORRUPTED PACKET
    # -------------------------
    if pkt is None:
        print("CORRUPTED PACKET RAW", data)

        # resend last valid ACK safely
        ack_pkt = PDU(0, expected_seq, 0, b"ACK")
        send_via_channel(sock, ack_pkt.encode(), addr)
        continue

    # -------------------------
    # FIN
    # -------------------------
    if pkt.flags == 1:
        print("FIN RECEIVED")
        break

    seq = pkt.seq

    # -------------------------
    # IN ORDER
    # -------------------------
    if seq == expected_seq:

        output_file.write(pkt.data)
        expected_seq += 1
        status = "OK"

    else:
        status = "NoErr"

    print(status, seq)

    # -------------------------
    # SEND CUMULATIVE ACK (IMPORTANT FIX)
    # -------------------------
    ack_pkt = PDU(0, expected_seq, 0, b"ACK")
    sock.sendto(ack_pkt.encode(), addr)

    # -------------------------
    # LOG
    # -------------------------
    log.write(
        f"{log_id}, pdu_exp={expected_seq-1}, "
        f"pdu_recv={seq}, status={status}\n"
    )
    log_id += 1

# ================= CLEANUP =================
output_file.close()
log.close()
sock.close()

print("RECEIVER COMPLETE")
expected_seq = int(config["COMMUNICATION"]["InitSeqNo"])