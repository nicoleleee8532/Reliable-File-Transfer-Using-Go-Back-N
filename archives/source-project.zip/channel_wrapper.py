# channel_wrapper.py
import random
import configparser

config = configparser.ConfigParser()
config.read("config.ini")

ERROR_RATE = int(config["COMMUNICATION"]["ErrorRate"])
LOST_RATE = int(config["COMMUNICATION"]["LostRate"])

def send_via_channel(sock, data, addr):
    """Simulate channel errors and losses"""
    # Simulate loss
    if LOST_RATE > 0:
        if random.randint(1, LOST_RATE) == 1:
            print(f"PACKET LOST (rate 1/{LOST_RATE})")
            return False
    
    # Simulate corruption
    if ERROR_RATE > 0:
        if random.randint(1, ERROR_RATE) == 1:
            # Corrupt the packet
            corrupted = bytearray(data)
            if len(corrupted) > 0:
                corrupted[0] ^= 0xFF  # Flip all bits in first byte
            sock.sendto(bytes(corrupted), addr)
            print(f"PACKET CORRUPTED (rate 1/{ERROR_RATE})")
            return True
    
    # Send normally
    sock.sendto(data, addr)
    return True