# test_sender_receiver.py
import subprocess
import time
import os
import configparser

def run_test(config_updates, test_name):
    """Run a single test with specific config"""
    # Update config file
    config = configparser.ConfigParser()
    config.read("config.ini")
    
    for key, value in config_updates.items():
        config["COMMUNICATION"][key] = str(value)
    
    with open("config.ini", "w") as f:
        config.write(f)
    
    # Start receiver in background
    receiver = subprocess.Popen(["python", "receiver.py"])
    time.sleep(1)  # Give receiver time to start
    
    # Run sender
    start_time = time.time()
    sender = subprocess.run(["python", "sender.py"])
    end_time = time.time()
    
    # Stop receiver
    receiver.terminate()
    time.sleep(0.5)
    
    # Verify file integrity
    with open("input.dat", "rb") as f1, open("received.dat", "rb") as f2:
        if f1.read() == f2.read():
            print(f"✓ {test_name}: Files match!")
        else:
            print(f"✗ {test_name}: Files don't match!")
    
    return end_time - start_time

# Run multiple tests
tests = [
    ({"SWSize": 4, "ErrorRate": 0, "LostRate": 0, "Timeout": 1000}, "Window=4, No Errors"),
    ({"SWSize": 8, "ErrorRate": 0, "LostRate": 0, "Timeout": 1000}, "Window=8, No Errors"),
    ({"SWSize": 4, "ErrorRate": 10, "LostRate": 0, "Timeout": 1000}, "10% Error Rate"),
    ({"SWSize": 4, "ErrorRate": 0, "LostRate": 10, "Timeout": 1000}, "10% Loss Rate"),
]

for config, name in tests:
    print(f"\nTesting: {name}")
    duration = run_test(config, name)
    print(f"Duration: {duration:.2f} seconds")