# multi_host_sender.py
from concurrent.futures import ThreadPoolExecutor

class MultiHostSender:
    def __init__(self, hosts):
        self.hosts = hosts  # List of (ip, port) tuples
    
    def send_to_host(self, host, file_path, host_id):
        print(f"Sending to host {host_id}: {host}")
        # Your sender logic here
        pass
    
    def send_all(self, file_path):
        with ThreadPoolExecutor(max_workers=len(self.hosts)) as executor:
            futures = []
            for i, host in enumerate(self.hosts):
                future = executor.submit(self.send_to_host, host, file_path, i)
                futures.append(future)
            
            # Wait for all to complete
            for future in futures:
                future.result()

# Usage
hosts = [
    ("127.0.0.1", 42039),
    ("127.0.0.1", 42040),
    ("127.0.0.1", 42041),
]
sender = MultiHostSender(hosts)
sender.send_all("input.dat")